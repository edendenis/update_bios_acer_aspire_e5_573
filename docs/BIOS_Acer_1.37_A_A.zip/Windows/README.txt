How to update the BIOS: 
Click "ZRT_137.exe" under Winodows mode


Release Note:
1. Update N16S-GT 4G vbios to 82.08.46.00.44
2. Update brightness table

